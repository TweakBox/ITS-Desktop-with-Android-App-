﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSLA.Classess
{
    public class Announcement
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public Image Poster { get; set; }
        
    }
}
